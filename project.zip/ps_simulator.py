#COMP9334 PS_simulator
#By z5082727 ShaoshenWang

import random
import math
import numpy as np
import matplotlib.pyplot as plt


def arrivals(s,k):
    l    = []
    rate = 7.2
    prev = 0
    random.seed(s)
    for _ in range(k):
        uni = random.random() #[0,1]
        a2  = random.uniform(0.75,1.17)
        a1  = -math.log(1-uni)/rate
        new = prev+a1*a2
        l.append(new)
        
        #print(a1)
        #l.append(a1)
        prev= new
        
    return l


def services(s,k):

    #(r/(1-b)t^(1-b))
    #t=(((1-b)*y)/r)^(1/(1-b))
    l  = []   
    a1 = 0.43
    a2 = 0.98   
    b  = 0.86
    r  = (1-b)/(a2**(1-b)-a1**(1-b))    
    f1 = r/(1-b)*(a1**(1-b))
    f2 = r/(1-b)*(a2**(1-b))
    Fa = r/(1-b)*(a1**(1-b))

    for _ in range(k):
        #uni=random.uniform(f1,f2)
        #t=(((1-b)*(uni))/r)**(1/(1-b))
        uni = random.uniform(0,1)
        t   = (((1-b)*(uni+Fa))/r)**(1/(1-b))
        l.append(t)
    return l


def ps_server(s,arrival,service,transient_end=2000):
    p       = 2000/s
    f       = 1.25+0.31*(p/200-1)#Ghz
    service = [x/f for x in service]
    length  = len(arrival)
    arrival = [arrival[i] for i in range(0,length,s)]#obtain new arrival and service time [1,s+1,2s+1...]
    service = [service[i] for i in range(0,length,s)]
    length  = len(arrival)
    
    INF           = 99999999
    m_c           = 0        #master_clock
    interval      = 0
    response_time = 0
    job_i         = 0
    job_list      = []
    next_dep      = INF
    next_arr      = arrival[0]
    event         = ("N")
    #transient_end = 2000
    
    #event=("A|D",(arrival_time,remaining_service_time))
    #job_list=[(arrival_time,remaining_service_time) ...]
    
    while True:
            
                
        if event[0] == "A":
            job_list.append([event[1],event[2]])
        if event[0] == "D":
            if job_i*s > transient_end:#remove transient part
                response_time += m_c-event[1]
            job_list = job_list[1:]
 
        if arrival == [] and job_list == []:# exit contidion
            break 
        
        if arrival != []:#obtain next arrival time
            next_arr = arrival[0]
        else:
            next_arr = INF
        if job_list == []:#obtain next departure time
            next_dep = INF
        else:
            job_list           = sorted(job_list,key = lambda x:x[1])
            next_dep_event     = job_list[0]
            num_of_job_in_list = len(job_list)
            next_dep           = round(job_list[0][1]*num_of_job_in_list,3)+m_c
            
        if next_arr < next_dep:
            interval = next_arr-m_c
            m_c      = next_arr
            event    = ("A",next_arr,service[job_i])
            arrival  = arrival[1:]               
            job_i   += 1
        else:
            interval = next_dep-m_c
            m_c      = next_dep
            event    = ("D",next_dep_event[0],next_dep_event[1])
            
            
            
            
        if job_list != []:#process
            num_of_job_in_list = len(job_list)
            for job in job_list:
                job[1] -= interval/num_of_job_in_list          
    #print(response_time)     
    return response_time/(length-transient_end/s)
    
#arrival=[1,2,3,5,15]
#service=[2.1,3.3,1.1,0.5,1.7]



def plot(s,end,transient_end):#plot y:response time x:number of jobs
    x=[]
    y=[]
    inter=50
    for i in range(1,end,inter):
        arrival=arrivals(1,i)
        service=services(1,i)
        y.append(ps_server(s,arrival,service,transient_end))
        x=[i for i in range(1,end,inter)]

    plt.plot(x,y)
    plt.show()

def find_min_response_time(s1,s2):# print mean response time 
    X=range(s1,s2)
    Y=[]
    for s in range(s1,s2):
        print("s={:}".format(s))
        arrival=arrivals(1,10000)
        service=services(1,10000)
        p=ps_server(s,arrival,service)
        Y.append(p)
        print("mean response time = ",p)
    plt.plot(X,Y)
    plt.show()
#s=6,7
def confidence_interval(s):
    tt=2.0452 #alpha=5%
    n=30      #repetition
    l=[]
 
    for seed in range(1,n+1):
        arrival=arrivals(seed,15000)
        service=services(seed,15000)
        l.append(ps_server(s,arrival,service))    
    s=np.std(l)
    t=np.mean(l)
    print("s=",s)
    print("mean",t)
    print("confidence interval",(t-(s/(n**0.5)*tt),t+(s/(n**0.5)*tt)))
    
def pair_test(s1,s2): 
    tt=2.0452
    n=30

    l1=[]
    l2=[]
    l=[0]*n
    for s in range(1,n+1):
        arrival=arrivals(s,15000)
        service=services(s,15000)
        l1.append(ps_server(s1,arrival,service))
        l2.append(ps_server(s2,arrival,service))

    for i in range(n):
        l[i]=l1[i]-l2[i]
    
    s=np.std(l)
    t=np.mean(l)
    #print(s)
    print((t-(s/(n**0.5)*tt),t+(s/(n**0.5)*tt)))
    #print(t)
    
    
def main():
    
    #confidence_interval(7)
    find_min_response_time(3,11)
    #print(np.mean(arrivals(1,1000))
    #arrivals(1,20)
    #plot(6,2000,0)
    #pair_test(6,7)    
    
if __name__=="__main__":
    #print(arrivals(200,3000)[-1])
    #arrival=[1,2,3,5,15]
    #service=[2.1,3.3,1.1,0.5,1.7]
    #print(ps_server(1,arrival,service,0))
    #arrivals(1,100)
    main()    

'''
x=[i for i in range(20)]

#plt.plot(x,arrival)
b=[0]*20
for i in range(20):
    for j in arrival:
        if i*0.08<=j<(i+1)*0.08:
            b[i]+=1
            
plt.plot(x,b)            
plt.show()

'''
